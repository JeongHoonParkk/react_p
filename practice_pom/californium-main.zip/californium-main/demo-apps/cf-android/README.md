# Californium - Android Demo

This demo shows, how the Californium libraries are used with Android.
It doesn't cover a close to production app, e.g. if you rotate the device, the function is more or less reseted.

## Build

Please use a current version of the Android Studio. Import the project there and build it with the Android Studio.
